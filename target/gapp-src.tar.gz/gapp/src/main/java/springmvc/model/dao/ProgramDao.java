package springmvc.model.dao;

import java.util.List;

import springmvc.model.Program;

public interface ProgramDao {
	
	Program getProgram(Integer p_id);
	
	List<Program> getProgram();
	
	Program saveProgram (Program program);
	
	void removeProgra (Program program);

}