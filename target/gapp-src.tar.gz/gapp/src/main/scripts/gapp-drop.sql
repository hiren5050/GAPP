drop table additional_info cascade;

drop table application_details cascade;

drop table applicationstatus cascade;

drop table applicationstatus_status cascade;

drop table degree_type cascade;

drop table deparment cascade;

drop table program cascade;

drop table education_background cascade;

drop table student_info cascade;


drop table user_info cascade;

drop table user_type cascade;



drop sequence hibernate_sequence;